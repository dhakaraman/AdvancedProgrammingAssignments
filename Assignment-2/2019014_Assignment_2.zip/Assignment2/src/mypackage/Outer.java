package mypackage;

public interface Outer {
	public void displayUserDetails();
	public void displayRewards();
}
