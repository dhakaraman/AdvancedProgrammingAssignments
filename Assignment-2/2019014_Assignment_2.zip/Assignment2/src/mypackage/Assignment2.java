package mypackage;

public class Assignment2 {

	public static void main(String[] args) {
		Zotato_App obj = new Zotato_App();
		obj.run();
	}
}
