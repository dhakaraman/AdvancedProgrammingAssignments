package mypackage;

public class Assignment3 {

	public static void main(String[] args) {
		Game obj = new Game();
		obj.run();

	}

}
